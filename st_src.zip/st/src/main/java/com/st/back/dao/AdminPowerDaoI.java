package com.st.back.dao;

import com.st.dao.BaseDaoI;
import com.st.model.Adminpower;


public interface AdminPowerDaoI extends BaseDaoI<Adminpower>{
	
}
