package com.st.back.dao;

import com.st.dao.BaseDaoI;
import com.st.model.Admins;


public interface AdminsDaoI extends BaseDaoI<Admins>{
	
}
