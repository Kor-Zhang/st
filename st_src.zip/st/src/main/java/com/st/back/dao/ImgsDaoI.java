package com.st.back.dao;

import com.st.dao.BaseDaoI;
import com.st.model.Imgs;


public interface ImgsDaoI extends BaseDaoI<Imgs>{
	
}
