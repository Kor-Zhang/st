package com.st.back.officialwebsite.dao;

import com.st.dao.BaseDaoI;
import com.st.model.OfficialwebsiteAboutUs;

public interface OwAboutUsBackDaoI extends BaseDaoI<OfficialwebsiteAboutUs>{
	
}
