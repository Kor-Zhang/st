package com.st.back.officialwebsite.util;

import com.st.back.util.BackMail;

public class OwBackMail extends BackMail{

}
