package com.st.back.officialwebsite;

import com.st.back.BackStatic;


public class OwBackStatic extends BackStatic{
	/*************************表名：见于PubStatic*****************************/
	/************************官网轮播资源路径：见于PubStatic*********************/
	/************************官网模块：用户意见记录状态*********************/
	//用户提交意见
	public final static Integer OFFICIALWEBSITE_CONTACT_US_STATUS_SUBMITED = 0;
	//管理员受理
	public final static Integer OFFICIALWEBSITE_CONTACT_US_STATUS_RECEIVE = 1;
	//管理员受理完毕
	public final static Integer OFFICIALWEBSITE_CONTACT_US_STATUS_DEALED = 2;
}
