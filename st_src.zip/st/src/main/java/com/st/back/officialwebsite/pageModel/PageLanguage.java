package com.st.back.officialwebsite.pageModel;

public class PageLanguage{
	private String lang;

	public String getLang() {
		return lang;
	}

	public void setLang(String lang) {
		this.lang = lang;
	}
	
}
