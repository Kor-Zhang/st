package com.st.back.officialwebsite.dao;

import com.st.dao.BaseDaoI;
import com.st.model.OfficialwebsiteMembers;

public interface OwMembersBackDaoI extends BaseDaoI<OfficialwebsiteMembers>{
	
}
