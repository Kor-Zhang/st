package com.st.back.exception;

import com.st.exception.STException;

public class STBackException extends STException{
	
	public STBackException() {
		super();
	}

	public STBackException(String message) {
		super(message);
	}
}
