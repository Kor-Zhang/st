package com.st.back.officialwebsite.util;

import java.util.UUID;

import com.st.back.util.BackTools;

public class OwBackTools extends BackTools{

}
