package com.st.back.exception;

public class AboutUsException extends STBackException {

	public AboutUsException() {
		super();
	}

	public AboutUsException(String message) {
		super(message);
	}
	
}
