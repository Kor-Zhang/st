package com.st.back.officialwebsite.dao;

import com.st.dao.BaseDaoI;
import com.st.model.OfficialwebsiteService;

public interface OwServiceBackDaoI extends BaseDaoI<OfficialwebsiteService>{
	
}
