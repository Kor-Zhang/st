package com.st.back.service;



public interface AdminPowerServiceI {

}
