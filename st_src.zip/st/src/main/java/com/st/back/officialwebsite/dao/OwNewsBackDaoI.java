package com.st.back.officialwebsite.dao;

import com.st.dao.BaseDaoI;
import com.st.model.OfficialwebsiteNews;

public interface OwNewsBackDaoI extends BaseDaoI<OfficialwebsiteNews>{
	
}
