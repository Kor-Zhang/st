package com.st.back.officialwebsite.dao;

import com.st.dao.BaseDaoI;
import com.st.model.OfficialwebsiteContactUs;


public interface OwContactUsBackDaoI extends BaseDaoI<OfficialwebsiteContactUs>{
	
}
