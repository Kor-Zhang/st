package com.st.back.service;

public interface RepairServiceI {

	public void repairMenuTree();
	public void repairAdmins();
	public void repairAll();
	public void repairUsers();
	public void repairCars();
	public void repairOrders() throws Exception;
}
