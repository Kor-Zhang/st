package com.st.back.exception;

public class AdminLoginRecordException extends STBackException {
	
	public AdminLoginRecordException() {
		super();
	}

	public AdminLoginRecordException(String message) {
		super(message);
	}
	
}
