package com.st.back.exception;

public class AdminUpdateRecordException extends STBackException {
	
	public AdminUpdateRecordException() {
		super();
	}

	public AdminUpdateRecordException(String message) {
		super(message);
	}
	
}
