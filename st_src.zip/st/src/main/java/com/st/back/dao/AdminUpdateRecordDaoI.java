package com.st.back.dao;

import com.st.dao.BaseDaoI;
import com.st.model.Adminupdaterecord;


public interface AdminUpdateRecordDaoI extends BaseDaoI<Adminupdaterecord>{
	
}
