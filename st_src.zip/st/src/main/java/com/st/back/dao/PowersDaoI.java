package com.st.back.dao;

import com.st.dao.BaseDaoI;
import com.st.model.Powers;

public interface PowersDaoI extends BaseDaoI<Powers>{
	
}
