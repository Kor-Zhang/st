package com.st.back.officialwebsite.dao;

import com.st.dao.BaseDaoI;
import com.st.model.Imgs;
import com.st.model.OfficialwebsiteAboutUs;

public interface OwImgsBackDaoI extends BaseDaoI<Imgs>{
	
}
