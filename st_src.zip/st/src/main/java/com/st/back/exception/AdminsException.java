package com.st.back.exception;

public class AdminsException extends STBackException {
	
	public AdminsException() {
		super();
	}

	public AdminsException(String message) {
		super(message);
	}
	
}
