package com.st.back.dao;

import com.st.dao.BaseDaoI;
import com.st.model.Systemddl;


public interface SystemddlDaoI extends BaseDaoI<Systemddl>{

}
