package com.st.back.dao.impl;

import org.springframework.stereotype.Repository;

import com.st.back.dao.SystemddlDaoI;
import com.st.dao.impl.BaseDaoImpl;
import com.st.model.Systemddl;

@Repository("systemddlDao")
public class SystemddlDaoImpl extends BaseDaoImpl<Systemddl> implements SystemddlDaoI{
	
}
 