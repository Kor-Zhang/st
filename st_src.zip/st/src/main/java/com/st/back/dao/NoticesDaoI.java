package com.st.back.dao;

import com.st.dao.BaseDaoI;
import com.st.model.Notices;


public interface NoticesDaoI extends BaseDaoI<Notices>{
	
}
