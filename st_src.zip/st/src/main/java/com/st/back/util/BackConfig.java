package com.st.back.util;

import com.st.util.PubConfig;


public class BackConfig extends PubConfig{
	
}
