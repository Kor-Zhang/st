package com.st.back.dao;

import com.st.dao.BaseDaoI;
import com.st.model.Adminloginrecord;

public interface AdminLoginRecordDaoI extends BaseDaoI<Adminloginrecord>{
	
}
