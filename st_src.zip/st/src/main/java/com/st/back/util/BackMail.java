package com.st.back.util;

import com.st.util.PubMail;


public class BackMail extends PubMail{
	
}
