package com.st.back.dao;

import com.st.dao.BaseDaoI;
import com.st.model.Menutree;


public interface MenuTreeDaoI extends BaseDaoI<Menutree> {
	
}
