package com.st.back.dao.impl;

import org.springframework.stereotype.Repository;

import com.st.back.dao.AdminUpdateRecordDaoI;
import com.st.dao.impl.BaseDaoImpl;
import com.st.model.Adminupdaterecord;

@Repository("adminUpdateRecordDao")
public class AdminUpdateRecordDaoImpl extends BaseDaoImpl<Adminupdaterecord> implements AdminUpdateRecordDaoI{
	
}
