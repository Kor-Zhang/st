package com.st.back.exception;

public class SystemddlException extends STBackException {
	
	public SystemddlException() {
		super();
	}

	public SystemddlException(String message) {
		super(message);
	}
}
