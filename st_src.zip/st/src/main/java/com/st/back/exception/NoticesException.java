package com.st.back.exception;

public class NoticesException extends STBackException {

	public NoticesException() {
		super();
	}

	public NoticesException(String message) {
		super(message);
	}
	
}
