package com.st.back.officialwebsite.service;

import com.st.back.officialwebsite.exception.OwImgsBackException;
import com.st.back.officialwebsite.pageModel.PageOwImgsAndInfoBack;
import com.st.back.officialwebsite.pageModel.PageOwImgsBack;
import com.st.back.officialwebsite.util.OwBackReturnJSON;
import com.st.model.Admins;


public interface OwImgsBackServiceI {

}
