package com.st.back.officialwebsite.action;

import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;

import com.st.back.action.BackBaseAction;
@ParentPackage("owBackPackage")
@Namespace("/back/ow")
public class OfficialwebsiteBackBaseAction extends BackBaseAction {

	
}
