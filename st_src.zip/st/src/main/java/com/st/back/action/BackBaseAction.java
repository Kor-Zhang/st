package com.st.back.action;

import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;

import com.st.action.BaseAction;
@ParentPackage(value = "backPackage")
@Namespace("/back")
public class BackBaseAction extends BaseAction{
	
}
