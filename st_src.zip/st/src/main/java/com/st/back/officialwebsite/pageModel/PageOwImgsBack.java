package com.st.back.officialwebsite.pageModel;

import com.st.pagemodel.BaseReceivePage;

public class PageOwImgsBack extends BaseReceivePage{

	private String id;
	private String imgName;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getImgName() {
		return imgName;
	}
	public void setImgName(String imgName) {
		this.imgName = imgName;
	}
	
}
