package com.st.front.officialwebsite.phone.util;

import com.st.util.PubMail;


public class OwFrontMail extends PubMail{
	
}
