package com.st.front.officialwebsite.pc.util;

import com.st.back.util.BackReturnJSON;

public class OwFrontReturnJSON<T> extends BackReturnJSON<T>{
	
}
