package com.st.front.officialwebsite.phone.dao;

import com.st.dao.BaseDaoI;
import com.st.model.OfficialwebsiteAboutUs;


public interface AboutUsFrontDaoI extends BaseDaoI<OfficialwebsiteAboutUs>{
}
