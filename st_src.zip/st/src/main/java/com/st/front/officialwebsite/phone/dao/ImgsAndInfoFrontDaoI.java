package com.st.front.officialwebsite.phone.dao;

import com.st.dao.BaseDaoI;
import com.st.model.ImgsAndInfo;



public interface ImgsAndInfoFrontDaoI extends BaseDaoI<ImgsAndInfo>{
	
}
