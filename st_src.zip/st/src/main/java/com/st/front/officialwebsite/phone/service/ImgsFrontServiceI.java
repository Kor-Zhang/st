package com.st.front.officialwebsite.phone.service;



public interface ImgsFrontServiceI {

}
