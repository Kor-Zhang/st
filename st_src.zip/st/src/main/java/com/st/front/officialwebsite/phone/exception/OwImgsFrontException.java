package com.st.front.officialwebsite.phone.exception;


public class OwImgsFrontException extends OfficialwebsiteFrontException {
	
	public OwImgsFrontException() {
		super();
	}

	public OwImgsFrontException(String message) {
		super(message);
	}
	
}
