package com.st.front.util;

import java.io.IOException;
import java.io.Serializable;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.st.util.PubReturnJSON;

public class FrontReturnJSON<T> extends PubReturnJSON<T>{
	
	
}
