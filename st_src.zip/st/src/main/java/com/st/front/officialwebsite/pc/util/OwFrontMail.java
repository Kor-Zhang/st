package com.st.front.officialwebsite.pc.util;

import com.st.util.PubMail;


public class OwFrontMail extends PubMail{
	
}
