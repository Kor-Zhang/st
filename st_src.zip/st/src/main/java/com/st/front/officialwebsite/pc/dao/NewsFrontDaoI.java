package com.st.front.officialwebsite.pc.dao;

import com.st.dao.BaseDaoI;
import com.st.model.OfficialwebsiteNews;


public interface NewsFrontDaoI extends BaseDaoI<OfficialwebsiteNews>{
}
