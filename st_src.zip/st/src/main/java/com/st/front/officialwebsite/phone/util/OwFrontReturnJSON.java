package com.st.front.officialwebsite.phone.util;

import com.st.back.util.BackReturnJSON;

public class OwFrontReturnJSON<T> extends BackReturnJSON<T>{
	
}
