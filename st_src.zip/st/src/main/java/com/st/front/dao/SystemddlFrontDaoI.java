package com.st.front.dao;

import com.st.dao.BaseDaoI;
import com.st.model.Systemddl;


public interface SystemddlFrontDaoI extends BaseDaoI<Systemddl>{

}
