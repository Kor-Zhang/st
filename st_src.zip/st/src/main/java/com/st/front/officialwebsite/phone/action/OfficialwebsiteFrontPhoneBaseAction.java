package com.st.front.officialwebsite.phone.action;

import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;

import com.st.action.BaseAction;

@ParentPackage(value = "owFrontPackage")
@Namespace("/front/ow/phone")
public class OfficialwebsiteFrontPhoneBaseAction extends BaseAction{
	
}
