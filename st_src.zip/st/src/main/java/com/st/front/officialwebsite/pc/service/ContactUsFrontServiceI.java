package com.st.front.officialwebsite.pc.service;

import com.st.front.officialwebsite.pc.exception.OfficialwebsiteFrontException;
import com.st.front.officialwebsite.pc.pageModel.PageContactUsFront;

public interface ContactUsFrontServiceI {

	void addContactUs(PageContactUsFront pageModel) throws OfficialwebsiteFrontException;

}
