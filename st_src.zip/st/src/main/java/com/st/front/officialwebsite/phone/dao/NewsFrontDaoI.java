package com.st.front.officialwebsite.phone.dao;

import com.st.dao.BaseDaoI;
import com.st.model.OfficialwebsiteNews;


public interface NewsFrontDaoI extends BaseDaoI<OfficialwebsiteNews>{
}
