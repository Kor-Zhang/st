package com.st.front.officialwebsite.pc.dao;

import com.st.dao.BaseDaoI;
import com.st.model.OfficialwebsiteAboutUs;
import com.st.model.OfficialwebsiteMembers;


public interface MembersFrontDaoI extends BaseDaoI<OfficialwebsiteMembers>{
}
