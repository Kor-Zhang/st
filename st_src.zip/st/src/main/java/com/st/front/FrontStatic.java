package com.st.front;

import java.io.File;

import com.st.PubStatic;

public class FrontStatic extends PubStatic{
	
}
