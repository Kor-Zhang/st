package com.st.front.officialwebsite.pc;

import java.io.File;

import com.st.PubStatic;
import com.st.back.util.BackConfig;
import com.st.front.FrontStatic;

public class OwFrontStatic extends FrontStatic{
	
}
