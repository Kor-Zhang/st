package com.st.front.officialwebsite.phone.dao;

import com.st.dao.BaseDaoI;
import com.st.model.OfficialwebsiteService;


public interface ServiceFrontDaoI extends BaseDaoI<OfficialwebsiteService>{
}
