package com.st.front.officialwebsite.pc.exception;

import com.st.front.exception.STFrontException;

public class ContactUsInfoErrorException extends OfficialwebsiteFrontException {
	
	public ContactUsInfoErrorException() {
		super();
	}

	public ContactUsInfoErrorException(String message) {
		super(message);
	}
	
}
